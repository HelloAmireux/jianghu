package com.amireux.web;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet(name = "user", value = "/user")
public class userServlet extends HttpServlet
{
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        this.doPost(req,resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String opr = req.getParameter("opr");
        if (opr.equals("login")) {
            System.out.println("登录了");
            String username = req.getParameter("username");
            String password = req.getParameter("password");
            String select=req.getParameter("id");
            System.out.println(username);
            System.out.println(password);
            System.out.println(select);
            req.setAttribute("ERROR", "账号不正确");
            //req.getRequestDispatcher("/login.jsp").forward(req, resp);
            req.getRequestDispatcher("/main.jsp").forward(req, resp);
            //login(req, resp, username, password);
        }

    //向前端返回数据
        //PrintWriter writer = resp.getWriter();
       // resp.getWriter().write("aaa");


    }
    private void login(HttpServletRequest req, HttpServletResponse resp, String username, String password) throws ServletException, IOException {
//        if (user == null) {
//            req.setAttribute("ERROR", "用户名不正确");
//            req.getRequestDispatcher("/login.jsp").forward(req, resp);
//        } else {
//            if (!user.getUserPassword().equals(password)) {
//                req.setAttribute("ERROR", "密码不正确");
//                req.getRequestDispatcher("/login.jsp").forward(req, resp);
//            } else {
//                //用session把这个user对象装起来，在页面上通过这个Session去
//                System.out.println("密码对啦");
//                req.getSession().setAttribute("userSession", user);
//                req.getRequestDispatcher("/WEB-INF/jsp/frame.jsp").forward(req, resp);
//            }
//        }
    }

}
